# Classe per salvare i metadati dell'utente

class MetaUser:
    def __init__ (self, name = None, password = None, institution = None, email = None, namefile = 'default', cloneNames = None, species = None, subspecies = None, color = None, lifeCycle = None, winged = None, pesticide = None, karyotype = None, host = None, samplingSite = None, samplingDate = None, notes = None):
        '''[cloneNames, species, subspecies, color, lifeCycle, winged, resistence, karyotype, host, samplingSite, notes]'''
        ''' la classe metaUser serve per salvare i dati dell'utente: '''
        ''' [name, password, institution, email, notes] '''

        # Dati specifici dell'utente
        self.name = name
        self.password = password
        self.institution = institution
        self.email = email

        # Dati specifici degli afidi
        self.species = species
        self.subspecies = subspecies
        self.color = color
        self.lifeCycle = lifeCycle
        self.winged = winged
        self.pesticide = pesticide
        self.karyotype = karyotype
        self.host = host
        self.samplingSite = samplingSite
        self.samplingDate = samplingDate
        self.namefile = namefile
        self.notes = notes
        
    def __str__(self):
        stringa = "user di nome: %s e species: %s" %(self.name, self.species)
        return (stringa)

    def setAfid(self, species, subspecies, color, lifeCycle, winged, pesticide, karyotype, host, samplingSite, samplingDate):
        self.species = species
        self.subspecies = subspecies
        self.color = color
        self.lifeCycle = lifeCycle
        self.winged = winged
        self.pesticide = pesticide
        self.karyotype = karyotype
        self.host = host
        self.samplingSite = samplingSite
        self.samplingDate = samplingDate

    def setUser(self, name, password, institution, email, namefile):
        self.name = name
        self.password = password
        self.institution = institution
        self.email = email
        self.namefile = namefile
