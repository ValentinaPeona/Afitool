# main.py

from PyQt4 import QtGui
import sys
import os  # For listing directory methods
import xlrd # Manage Excel Files
import math
import ast
import welcome9
import Dialog
import protocolDialog
import dialognew
import plotWindow
import requests
import numpy as np
import matplotlib.patches as mpatches
import json
from Afide import *
from MetaUser import *

# per dare lo stile ggplot ai grafici, così è molto più carino
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt4agg import (FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar)
import matplotlib.pyplot as plt
plt.style.use('ggplot')
#plt.style.use('fivethirtyeight')

PATH = 'http://aphidfitness.net/AfitoolNew/'
dizionario = {}
protocolData = None
email = 'email'
password = 'password'

class Form1(QtGui.QMainWindow, welcome9.Ui_MainWindow):

    def __init__(self, parent = None):
        super(self.__class__, self).__init__()
        self.setupUi(self)

        # plot window set come None inizialmente
        self.window2 = None
        self.dialog = None
        self.protocolDialog = None
        self.dialognew = None

        # other protocols
        self.cbProtocol.currentIndexChanged.connect(self.editProtocol)
        
        # upload button
        self.btnUpload.clicked.connect(self.plotButton)
        self.btnUpload.clicked.connect(self.smistaFile)
        self.btnUpload.clicked.connect(self.getUserMetadata)
        self.btnUpload.clicked.connect(self.getAfidMetadata)
        self.btnUpload.clicked.connect(self.setProtocol)
        self.btnUpload.clicked.connect(self.postNewUser)

        # browse button
        self.btnBrowse.clicked.connect(self.chooseFile)

        # plot button
        self.btnPlot.clicked.connect(self.checkPlot)

        # Dialog indici
        self.btnView.clicked.connect(self.showNew)
        self.btnView.clicked.connect(self.showIndexNew)

        # save files
        self.btnSave.clicked.connect(self.saveFile)

        #clean button
        self.btnClear.clicked.connect(self.cleanData)

        self.btnGet.clicked.connect(self.getDatasetList)
        self.btnLoad.clicked.connect(self.getMyDataset)

        self.lineNewEmail.textChanged.connect(self.enableUploadButton)

        self.btnLogOut.clicked.connect(self.logMeOut)

        self.userData = None
        self.afidi = None


### *** Dialogo con il server *** ###

## ** Nuovo utente ** ##

    def postNewUser(self):
        global PATH
        r = requests.post(PATH + 'postNewUser.php', data = {'nameUser' : self.userData.name, 'password' : self.userData.password, 'institution': self.userData.institution, 'email':self.userData.email, 'nameDataset': self.userData.namefile, 'species' : self.userData.species, 'subspecies': self.userData.subspecies, 'color' : self.userData.color, 'life' : self.userData.lifeCycle, 'pesticide' : self.userData.pesticide, 'karyotype' : self.userData.karyotype, 'wing' : self.userData.winged, 'plant' : self.userData.host, 'samplingsite' : self.userData.samplingSite, 'birth' : repr(self.afidi.nascite), 'z' : self.afidi.z, 'xmax' : self.afidi.xmax, 'clones' : repr(self.afidi.nomiCeppi), 'crowding' : repr(self.afidi.crowding), 'username' : self.userData.name, 'samplingdate' : self.userData.samplingDate, 'notes' : self.userData.notes})
        if r.text == '200':
            self.newStatusLabel.setText('Status of your dataset: correctly uploaded')
        else:
            self.newStatusLabel.setText('Status of your dataset: I could not uploaded your dataset on the Afit server')
        self.window2.mplfigs.setCurrentRow(0)

    def postNewDataset(self):
        global email
        global password
        email = self.lineLogUsername.text()
        password = self.lineLogPassword.text()
        global PATH
        print('postNewDataset: ', self.afidi.crowding)
        print('postNewDataset: ', repr(self.afidi.crowding))
        r = requests.post(PATH + 'postNewDataset.php', data = {'password' : password, 'email' : email, 'nameDataset': self.userData.namefile, 'species' : self.userData.species, 'subspecies': self.userData.subspecies, 'color' : self.userData.color, 'life' : self.userData.lifeCycle, 'pesticide' : self.userData.pesticide, 'karyotype' : self.userData.karyotype, 'wing' : self.userData.winged, 'plant' : self.userData.host, 'samplingsite' : self.userData.samplingSite, 'birth' : repr(self.afidi.nascite), 'z' : self.afidi.z, 'xmax' : self.afidi.xmax, 'clones' : repr(self.afidi.nomiCeppi), 'crowding' : repr(self.afidi.crowding), 'institution' : self.userData.institution, 'username' : self.userData.name, 'notes' : self.userData.notes, 'samplingdate' : self.userData.samplingDate})

## ** Utente registrato ** ##
        
    def getDatasetList(self):
        global email
        global password
        email = self.lineLogUsername.text()
        password = self.lineLogPassword.text()
        global PATH
        r = requests.post(PATH + 'getDatasetList.php', data = {'email' : email, 'password' : password})
        d = json.loads(r.text)
        self.logDataNames.clear()
        for el in d:
            self.logDataNames.addItem(el['ID'] + " - " + el['name'])
        try:
            self.btnUpload.clicked.disconnect(self.postNewUser)
        except:
            pass
        self.btnUpload.clicked.connect(self.postNewDataset)
        self.btnLoad.setEnabled(True)
        self.btnLogOut.setEnabled(True)
        self.lineNewUsername.setEnabled(False)
        self.lineNewPassword.setEnabled(False)
        self.lineNewEmail.setEnabled(False)
        self.btnUpload.setEnabled(True)

    def getMyDataset(self):
        global email
        global password
        ID = self.logDataNames.currentText()
        ID = ID.split(' - ')[0]
        global PATH
        r = requests.post(PATH + 'getDataset.php', data = {'ID' : ID, 'email' : email, 'password' : password})
        if r.text == '404':
            self.newStatusLabel.setText('Status of your dataset: dataset ' + self.logDataNames.currentText() + ' not found')
        elif r.text == '403':
            self.newStatusLabel.setText('Status of your dataset: you have not the permission to access this dataset')
        else:
            self.lineNewUsername.setEnabled(False)
            self.lineNewPassword.setEnabled(False)
            self.lineNewEmail.setEnabled(False)
        w = json.loads(r.text)
        print(w)
        Form1.parseJson(self, w)
        

    def parseJson(self, dataset):
        username = dataset[0]['username']
        institution = dataset[0]['institution']
        self.lineNewUsername.setText(username)
        self.lineNewInstitution.setText(institution)
        self.lineNewEmail.setText(self.lineLogUsername.text())
        namefile = dataset[0]['name']
        self.lineNewFile.setText(namefile)
        cloneNames = dataset[0]['clones']
        species = dataset[0]['species']
        self.lineSpecies.setText(species)
        subspecies = dataset[0]['subspecies']
        self.lineSubspecies.setText(subspecies)
        color = dataset[0]['color']
        self.lineColor.setText(color)
        
        lifeCycle = dataset[0]['life']
        
        if lifeCycle == 'Holocyclic':
            self.cbLife.setCurrentIndex(1)
        else:
            self.cbLife.setCurrentIndex(2)

        winged = dataset[0]['wing']

        if winged == 'Alate':
            self.cbWing.setCurrentIndex(1)
        else:
            self.cbWing.setCurrentIndex(2)
            
        pesticide = dataset[0]['pesticide']
        self.linePesticide.setText(pesticide)
        karyotype = dataset[0]['karyotype']
        self.lineKaryotype.setText(karyotype)
        host = dataset[0]['plant']
        self.lineHost.setText(host)
        samplingSite = dataset[0]['samplingsite']
        self.lineSite.setText(samplingSite)
        samplingDate = dataset[0]['samplingdate']
        self.lineDate.setText(samplingDate)
        notes = dataset[0]['notes']
        self.lineEdit.setText(notes)

        self.newStatusLabel.setText('Status of your dataset: ' + namefile + ' loaded correctly from the Afit server!')

        #da aggiungere institution samplingdate e notes quando db caricato
        # creo i metadati
        self.userData = MetaUser(password = self.lineLogPassword, email = self.lineLogUsername, namefile = namefile, cloneNames = cloneNames, species = species, subspecies = subspecies, color = color, lifeCycle = lifeCycle, winged = winged, pesticide = pesticide, karyotype = karyotype, host = host, samplingSite = samplingSite)

        # creo oggetto afide
        
        if self.window2 is None:
            self.window2 = Form2(self)
        self.window2.show()

        afidiDict = ast.literal_eval(dataset[0]['birth'])
        crowding = ast.literal_eval(dataset[0]['crowding'])
        Form1.uploadDict(self, afidiDict)
        if crowding:
            Afide.setCrowding(self, self.afidi, crowding)
            self.checkBox.setEnabled(True)
        else:
            self.checkBox.setEnabled(False)

## ** Utente registrato: log out ** ##

    def logMeOut(self):
        global email
        email = 'email'
        global password
        password = 'password'
        self.lineLogUsername.setPlaceholderText('e-mail')
        self.lineNewEmail.setEnabled(True)
        self.lineLogPassword.setPlaceholderText('Password')
        self.lineNewPassword.setEnabled(True)
        self.lineNewUsername.setEnabled(True)
        self.userData = None
        self.afidi = None
        self.newStatusLabel.setText('Status of your dataset: you successfully logged out')

### *** Salvataggio metadati in locale *** ###
## ** User ** ##

    def getUserMetadata (self):
        name = self.lineNewUsername.text()
        password = self.lineNewPassword.text()
        institution = self.lineNewInstitution.text()
        email = self.lineNewEmail.text()
        namefile = self.lineNewFile.text()
        namefile = namefile.split('/')[-1].split('.')[0]
        if self.userData is None:
            self.userData = MetaUser(name, password, institution, email, namefile)
        else:
            self.userData.setUser(name, password, institution, email, namefile)

## ** Afidi ** ##

    def getAfidMetadata (self):
        species = self.lineSpecies.text()
        subspecies = self.lineSubspecies.text()
        color = self.lineColor.text()
        lifeCycle = str(self.cbLife.currentText())
        pesticide = self.linePesticide.text()
        karyotype = self.lineKaryotype.text()
        winged = str(self.cbWing.currentText())
        host = self.lineHost.text()
        sampling = self.lineSite.text()
        date = self.lineDate.text()
        if self.userData is None:
            self.userData = MetaUser()
        try:
            self.userData.setAfid(species, subspecies, color, lifeCycle, winged, pesticide, karyotype, host, sampling, date)
        except:
            self.newStatusLabel.setText('Problems with the aphids metadata')
## ** Protocollo di allevamento ** ##

    def editProtocol(self):
        if self.cbProtocol.currentText() == "Other...":
            if self.protocolDialog is None:
                self.protocolDialog = Form4(self)
            self.protocolDialog.show()
            self.protocolDialog.okButton.clicked.connect(self.saveProtocol)
        if self.cbProtocol.currentText() == 'Rearing Protocol':
            pass
        if self.cbProtocol.currentText() == 'Nardelli et al. 2016':
            self.saveProtocol()

    def saveProtocol(self):
        global protocolData
        if self.cbProtocol.currentText() == 'Nardelli et al. 2016':
            protocolData = 'Nardelli et al. 2016'
        else:
            protocolData = window.protocolDialog.protocolText.toPlainText()
        print(protocolData)

    def setProtocol(self):
        global protocolData
        if protocolData:
            self.afidi.protocol = protocolData

### *** Upload del dataset per analisi in locale *** ###
## ** Scelta dei file di upload ** ##

    def chooseFile (self):
        try:
            q = QtGui.QFileDialog()
            file = q.getOpenFileName(self, "Choose a file", options = QtGui.QFileDialog.DontUseNativeDialog) #così ottengo il path del file da analizzare
            if( file ):
                self.lineNewFile.setText( file )
        except ValueError as e:
            self.newStatusLabel.setText(e)

    def enableUploadButton(self):
        text = self.lineNewEmail.text()
        if '@' in text:
            self.btnUpload.setEnabled(True)
        else:
            self.btnUpload.setEnabled(False)

## ** Smistamento del file secondo estensione ** ##

    def smistaFile(self):
        nameFile = self.lineNewFile.text()
        ext = nameFile.split("/")[-1].split(".")[-1]
        if (ext == "csv"):
            import csv
            try:
                lista = Form1.readCSV(nameFile)
                afidiDict = Form1.shapeDict(lista)
                self.afidi = Form1.uploadDict(self, afidiDict)
            except:
                self.newStatusLabel.setText("Status of your dataset: you're file cannot be read as a csv")
        elif (ext == "xlsx"):
            Form1.uploadExcel(self)
        elif (ext == "xls"):
            Form1.uploadExcel(self)
        elif (ext == "txt"):
            import csv
            try:
                with open(nameFile, 'rt') as f:
                    reader = csv.reader(f)
                    lista = list(reader)
                if ("\t" in lista[0][0]):
                    lista = Form1.readTSV(nameFile)
                    afidiDict = Form1.shapeDict(lista)
                    Form1.uploadDict(afidiDict)
                else:
                    lista = Form1.readCSV(nameFile)
                    afidiDict = Form1.shapeDict(lista)
                    Form1.uploadDict(afidiDict)
            except:
                self.newStatusLabel('Status of your dataset: cannot parse the file as CSV nor as TSV. Incorrect format file')
        else:
            self.newStatusLabel("Status of your dataset: cannot parse the file")

## ** Excel ** ##

    def uploadExcel (self):
        file = self.lineNewFile.text()
        
        try:
            wb = xlrd.open_workbook( file )
            self.newStatusLabel.setText( 'Status of your dataset: Upload done!' )
            try:
                self.afidi = Form1.parseExcel(self, wb)     #oggetto di classe Afide con i dati di partenza presi dal file inserito dall'utente
                self.newStatusLabel.setText('Status of your dataset: uploaded and parsed correctly!')
                
            except:
                self.newStatusLabel.setText("Status of your dataset: I can not parse the file")
        except:
            self.newStatusLabel.setText('Status of your dataset: File excel not uploaded! Try again! ')
            
        try:
            for i in range(0,len(self.afidi.nomiCeppi)):
                self.window2.mplfigs.addItem(self.afidi.nomiCeppi[i])
        except:
            self.newStatusLabel.setText('Status of your dataset: some problems with the format of your file!')

        # creo le varie curve di fecondità giornaliera, tutte insieme ma non funziona e non so perché
        self.window2.mplfigs.addItem("Clone fecundity")
        global dizionario
        dizionario["Clone fecundity"] = Afide.cloneFecundity2(self.afidi)
        
        #qui creo le curve di crescita e le si plotta tutte insieme nella canvas con etichette
        for i, val in enumerate(self.afidi.nomiCeppi):
            afidi = Afide.growthCurve(self, self.afidi, self.afidi.nascite[self.afidi.nomiCeppi[i]], self.afidi.nomiCeppi[i])

        self.window2.mplfigs.addItem("GrowthCurve")
        dizionario["GrowthCurve"] = Afide.createGrowthCurve(self, self.afidi)
        afidi = Afide.meanFitness(self, self.afidi)

    def parseExcel(self, wb):
        global dizionario
        sheet = wb.sheet_by_index(0)
        repliche = sheet.nrows - 1

        # creo un dizionario con keys nome dei ceppi, values con la lista della fecondità giornaliera
        ceppi = {}
        z = []
        xmax = []
        nomi = sheet.col_values(0,0)
        control = False

        if 'Crowding' in nomi:
            nc = [x.lower() for x in nomi].count('crowding')
            control = True
            self.checkBox.setEnabled(True)
            # elimino il valore Crowding tra i nomi
            #del nomi[(len(nomi) - nc) : len(nomi)]
            crowding = {'iniPop': None, 'days': None, 'endPop':None}
            crowd = []

            i = len(nomi) - nc
            for x in range(i, len(nomi)):
                nomi[x] = nomi[x].lower()
                
            mediaIni = []
            mediaDays = []
            mediaEnd = []

            for x in range((len(nomi)-nc), len(nomi)):
                crowd = list(filter(('').__ne__, sheet.row_values(x, 1)))
                mediaIni.append(crowd[0])
                mediaDays.append(crowd[1])
                mediaEnd.append(crowd[2])

            crowding['iniPop'] = mediaIni
            crowding['days'] = mediaDays
            crowding['endPop'] = mediaEnd

            del nomi[(len(nomi) - nc) : len(nomi)]

        else:
            self.checkBox.setEnabled(False)
        
        for i in range(0, len(nomi)):
            x = sheet.row_values(i,1)
            x = list(filter(('').__ne__, x))
            ceppi[nomi[i]] = x
            z.append(len(ceppi[nomi[i]]))

        for i in range(0, len(nomi)):
            q = ceppi[nomi[i]]
            w = 0
            for j in range(0, len(q)):
                if q[j] == 0:
                    w += 1
                else:
                    xmax.append(w)
                    break
        try:
            global dizionario
            if control:
                afidi = Afide(ceppi, z, xmax, crowding)
            else:
                afidi = Afide(ceppi, z, xmax)
            for i in range(0, len(nomi)):
                global dizionario
                fig1 = Figure()
                ax1x1 = fig1.add_subplot(111)
                ax1x1.plot(range(1, len(ceppi[nomi[i]])+1), ceppi[nomi[i]])
                titolo = "Daily fecundity of " + nomi[i]
                ax1x1.set_title(titolo)
                ax1x1.set_xlabel('Days')
                ax1x1.set_ylabel('Number of aphids')
                dizionario[nomi[i]] = fig1
            return(afidi)
        except:
            self.newStatusLabel.setText('Problems with the creation of the plots, try again')

## ** Csv Txt ** ##

    def parseDict(self, afidiDict):
        global dizionario
        repliche = len(afidiDict)

        # creo un dizionario con keys nome dei ceppi, values con la lista della fecondità giornaliera
        ceppi = {}
        z = []
        xmax = []
        nomi = []
        for key in afidiDict:
            nomi.append(key)
            z.append(len(afidiDict[key]))
        control = False
        if 'Crowding' in nomi:
            control = True
            self.checkBox.setEnabled(True)
            # elimino il valore Crowding tra i nomi
            del nomi[-1]
            crowding = {'iniPop': None, 'days': None, 'endPop':None}
            crowd = []

            # il dizionario crowding comprende tre parametri:
            # numero di afidi iniziali = iniPop
            # quanti giorni è durato l'esperimento = days
            # numero di afidi finali = endPop
            for i in range(1, len(nomi)+1):
                crowd.append(sheet.col_values(i, len(nomi)))
            crowding['iniPop'] = crowd[0]
            crowding['days'] = crowd[1]
            crowding['endPop'] = crowd[2]
        else:
            self.checkBox.setEnabled(False)

        for i in range(0, len(nomi)):
            q = afidiDict[nomi[i]]
            w = 0
            for j in range(0, len(q)):
                if q[j] == 0:
                    w += 1
                else:
                    xmax.append(w)
                    break
            
        global dizionario
        if control:
            afidi = Afide(afidiDict, z, xmax, crowding)
        else:
            afidi = Afide(afidiDict, z, xmax)
        for i in range(0, len(nomi)):
            global dizionario
            fig1 = Figure()
            ax1x1 = fig1.add_subplot(111)
            ax1x1.plot(range(1, len(afidiDict[nomi[i]])+1), afidiDict[nomi[i]])
            titolo = "Daily fecundity of " + nomi[i]
            ax1x1.set_title(titolo)
            ax1x1.set_xlabel('Days')
            ax1x1.set_ylabel('Number of aphids')
            dizionario[nomi[i]] = fig1
        return(afidi)

    def uploadDict(self, afidiDict):
        self.afidi = Form1.parseDict(self, afidiDict)
        for i in range(0,len(self.afidi.nomiCeppi)):
            self.window2.mplfigs.addItem(self.afidi.nomiCeppi[i])
        self.window2.mplfigs.addItem("Clone fecundity")
        global dizionario
        dizionario["Clone fecundity"] = Afide.cloneFecundity2(self.afidi)
        for i, val in enumerate(self.afidi.nomiCeppi):
            afidi = Afide.growthCurve(self, self.afidi, self.afidi.nascite[self.afidi.nomiCeppi[i]], self.afidi.nomiCeppi[i])
        self.window2.mplfigs.addItem("GrowthCurve")
        dizionario["GrowthCurve"] = Afide.createGrowthCurve(self, self.afidi)
        afidi = Afide.meanFitness(self, self.afidi)

    def shapeDict(lista):
        afidi = {}
        for i in range(0, len(lista)):
            nome = lista[i][0]
            afidi[nome] = [int(x) for x in lista[i][1:]]
            afidi[nome] = list(filter(('').__ne__, afidi[nome]))
        return(afidi)

    def readCSV(nameFile):
        import csv
        with open(nameFile, 'rt') as f:
            reader = csv.reader(f, delimiter = ",")
            lista = list(reader)
        return(lista)

    def readTSV(nameFile):
        import csv
        with open(nameFile, 'rt') as f:
            reader = csv.reader(f, delimiter = "\t")
            lista = list(reader)
        return(lista) 

### *** Finestra di plot *** ###
            
    def plotButton (self):
        if self.window2 is None:
            self.window2 = Form2(self)
        self.window2.show()

    def checkPlot(self):
        statusRa = self.checkRa.isChecked()
        statusWhite = self.checkWhite.isChecked()
        statusLambda = self.checkLambda.isChecked()
        statusRm = self.checkRm.isChecked()
        statusCrowding = self.checkBox.isChecked()
        global dizionario
        if (statusRa or statusWhite or statusLambda or statusRm or statusCrowding):
            fig_dict = Afide.createIndexCurve(self, self.afidi, statusRa, statusWhite, statusLambda, statusRm)
            if statusCrowding:
                fig_dict.update(Afide.crowdingEffect2(self, self.afidi))
            global dizionario
            dizionario.update(fig_dict)
            if self.window2 is None:
                self.newStatusLabel.setText('Status of your dataset: No dataset uploaded')
            else:
                for key in fig_dict.keys():
                    self.window2.mplfigs.addItem(key)
        else:
            if self.window2 is None:
                self.newStatusLabel.setText('Status of your dataset: No dataset uploaded')
            else:
                if self.window2 is None and not dizionario:
                    self.newStatusLabel.setText('Status of your dataset: No dataset uploaded')
                if not dizionario:
                    self.newStatusLabel.setText('Status of your dataset: No dataset uploaded')
                else:
                    self.window2.show()
                    self.newStatusLabel.setText('Status of your dataset: no indexes selected for plotting!')

### *** Finestra degli indici *** ###

    def showDialog(self):
        if self.dialog is None:
            self.dialog = Form3(self)
        self.dialog.show()

    def showIndices(self, afidi):
        if self.afidi is None:
            self.dialog.plainTextEdit.clear()
            self.dialog.plainTextEdit.appendPlainText("You haven't uploaded or retrieved a dataset yet")
        else:
            self.dialog.plainTextEdit.clear()
            testo = Afide.createIndices(self.afidi)
            self.dialog.plainTextEdit.appendPlainText(testo)

    def showNew(self):
        if self.dialognew is None:
            self.dialognew = Form5(self)
        self.dialognew.show()

    def showIndexNew(self):
        if self.afidi is None:
            self.dialognew.textEdit.clear()
            testo = 'ciao normale <br> <b> ciao bold </b>'
            self.dialognew.textEdit.insertHtml(testo)
        else:
            self.dialognew.textEdit.clear()
            testo = Afide.createIndexNew(self.afidi)
            self.dialognew.textEdit.insertHtml(testo)

        
### *** Salvataggio analisi *** ###

    def saveFile (self):
        if self.afidi is None:
            self.newStatusLabel.setText('Status of your dataset: No dataset to save, upload a dataset')
        else:
            name = QtGui.QFileDialog.getSaveFileName(self, 'Save File')
            #try:
            Form1.exportXls(self, self.afidi, name)
            #    self.newStatusLabel.setText("Status of your dataset: file saved")
            #except:
            #    self.newStatusLabel.setText("Status of your dataset: problems with saving the file")

    def exportXls(self, afidi, fileName):
        Afide.exportXls(self, afidi, fileName)

### *** Pulizia del vecchio dataset *** ###

    def cleanData (self):
        global dizionario
        dizionario = {}
        global protocolData
        protocolData = None
        self.userData = None
        self.afidi = None
        self.lineLogUsername.clear()
        self.lineLogPassword.clear()
        self.logDataNames.clear()
        self.logDataNames.addItem("Dataset to retrieve")
        self.lineNewEmail.clear()
        self.lineNewEmail.setEnabled(True)
        self.lineNewPassword.clear()
        self.lineNewUsername.clear()
        self.lineNewUsername.setEnabled(True)
        self.lineNewPassword.setEnabled(True)
        self.lineNewInstitution.clear()
        self.lineSpecies.clear()
        self.lineSubspecies.clear()
        self.cbLife.clear()
        self.cbLife.addItem('Life Cycle')
        self.cbLife.addItem("Holocyclic")
        self.cbLife.addItem("Anolocyclic")
        self.cbWing.clear()
        self.cbWing.addItem("Winged Morph")
        self.cbWing.addItem("Alate")
        self.cbWing.addItem("Apterous")
        self.lineKaryotype.clear()
        self.lineColor.clear()
        self.lineHost.clear()
        self.lineSite.clear()
        self.lineDate.clear()
        self.linePesticide.clear()
        self.cbProtocol.clear()
        self.cbProtocol.addItem("Rearing Protocol")
        self.cbProtocol.addItem("Nardelli et al. 2016")
        self.cbProtocol.addItem("Other...")
        self.lineEdit.clear()
        self.lineNewFile.clear()
        self.newStatusLabel.setText('Status of your dataset:')
        ## pulizia checkbox ###
        self.checkRm.setChecked(False)
        self.checkLambda.setChecked(False)
        self.checkWhite.setChecked(False)
        self.checkRa.setChecked(False)
        self.checkBox.setChecked(False)
        if self.window2:
            self.window2.mplfigs.clear()
        if self.dialog:
            self.dialog.plainTextEdit.clear()
        try:
            self.btnUpload.clicked.disconnect(self.postNewDataset)
            self.btnUpload.clicked.connect(self.postNewUser)
        except:
            pass
        self.btnUpload.setEnabled(False)
        self.btnLoad.setEnabled(False)
        self.btnLogOut.setEnabled(False)
        
class Form2 (QtGui.QMainWindow, plotWindow.Ui_MainWindow):
    def __init__(self, parent=None):
        #QtGui.QWidget.__init__(self, parent)
        super(self.__class__, self).__init__()
        self.setupUi(self)

        fig = Figure()
        self.showPlot(fig)
        self.mplfigs.itemClicked.connect(self.Check)

    # funzione di interfaccia che raccoglie il nome dell'item cliccato che dovrà poi portare alla visualizzazione del plot associato
    def CheckIniziale(self, testo):
        self.removePlot()
        global dizionario
        Form2.showPlot(self, dizionario[testo])

    def Check (self, item):
        testo = item.text()
        self.removePlot()
        global dizionario
        Form2.showPlot(self, dizionario[testo]) #questa funzione manda il nome dell'item cliccato per visualizzare il plot a lui associato

    #funzione per visualizzare il plot selezionato tramite click dell'utente
    def showPlot (self, figura):
        self.canvas = FigureCanvas(figura)
        self.mplvl.addWidget(self.canvas)
        self.canvas.draw()
        self.toolbar = NavigationToolbar(self.canvas, self.mplwindow, coordinates=True)
        self.mplvl.addWidget(self.toolbar)

    def removePlot (self):
        self.mplvl.removeWidget(self.canvas)
        self.canvas.close()
        self.mplvl.removeWidget(self.toolbar)
        self.toolbar.close()

class Form3 (QtGui.QDialog, Dialog.Ui_Dialog):
    def __init__(self, parent=None):
        #QtGui.QWidget.__init__(self, parent)
        super(self.__class__, self).__init__()
        self.setupUi(self)

class Form4 (QtGui.QDialog, protocolDialog.Ui_ProtocolDialog):
    def __init__(self, parent = None):
        super(self.__class__, self).__init__()
        self.setupUi(self)

class Form5 (QtGui.QDialog, dialognew.Ui_Dialog):
    def __init__(self, parent = None):
        super(self.__class__, self).__init__()
        self.setupUi(self)
        
if __name__ == '__main__':

    import sys
    app = QtGui.QApplication(sys.argv)
    window = Form1()
    window.setWindowTitle("Afit")
    window.show()
    sys.exit(app.exec_())
