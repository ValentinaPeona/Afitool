# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ManualWindow.ui'
#
# Created by: PyQt4 UI code generator 4.12
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ManualWindow(object):
    def setupUi(self, ManualWindow):
        ManualWindow.setObjectName(_fromUtf8("ManualWindow"))
        ManualWindow.resize(663, 723)
        self.centralwidget = QtGui.QWidget(ManualWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.textEdit = QtGui.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(10, 10, 641, 631))
        self.textEdit.setObjectName(_fromUtf8("textEdit"))
        self.btnClose = QtGui.QPushButton(self.centralwidget)
        self.btnClose.setGeometry(QtCore.QRect(520, 650, 110, 32))
        self.btnClose.setObjectName(_fromUtf8("btnClose"))
        self.btnDownload = QtGui.QPushButton(self.centralwidget)
        self.btnDownload.setGeometry(QtCore.QRect(410, 650, 110, 32))
        self.btnDownload.setObjectName(_fromUtf8("btnDownload"))
        ManualWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(ManualWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 663, 22))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        self.menuManual = QtGui.QMenu(self.menubar)
        self.menuManual.setObjectName(_fromUtf8("menuManual"))
        ManualWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(ManualWindow)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        ManualWindow.setStatusBar(self.statusbar)
        self.actionQuit = QtGui.QAction(ManualWindow)
        self.actionQuit.setObjectName(_fromUtf8("actionQuit"))
        self.menuManual.addAction(self.actionQuit)
        self.menubar.addAction(self.menuManual.menuAction())

        self.retranslateUi(ManualWindow)
        QtCore.QObject.connect(self.actionQuit, QtCore.SIGNAL(_fromUtf8("triggered()")), ManualWindow.close)
        QtCore.QObject.connect(self.btnClose, QtCore.SIGNAL(_fromUtf8("released()")), ManualWindow.close)
        QtCore.QMetaObject.connectSlotsByName(ManualWindow)

    def retranslateUi(self, ManualWindow):
        ManualWindow.setWindowTitle(_translate("ManualWindow", "Manual", None))
        self.textEdit.setHtml(_translate("ManualWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'.SF NS Text\'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Da aggiungere il manuale</p></body></html>", None))
        self.btnClose.setText(_translate("ManualWindow", "Close", None))
        self.btnDownload.setText(_translate("ManualWindow", "Download PDF", None))
        self.menuManual.setTitle(_translate("ManualWindow", "Manual", None))
        self.actionQuit.setText(_translate("ManualWindow", "Quit", None))

