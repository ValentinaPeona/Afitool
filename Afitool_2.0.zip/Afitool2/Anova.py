class Anova:
	def __init__(self, ra, rm, wwrm, finiterate, name):
		self.name = [name]
		self.ra = {}
		self.ra[name] = [*ra.values()]
		self.rm = {}
		self.rm[name] = [*rm.values()]
		self.wwrm = {}
		self.wwrm[name] = [*wwrm.values()]
		self.finiterate = {}
		self.finiterate[name] = [*finiterate.values()]
        
	def update(ANOVA, ra, rm, wwrm, finiterate, name):
		ANOVA.name.append(name)
		print(ANOVA.name)
		ANOVA.ra[name] = [*ra.values()]
		ANOVA.rm[name] = [*rm.values()]
		ANOVA.wwrm[name] = [*wwrm.values()]
		ANOVA.finiterate[name] = [*finiterate.values()]
		return ANOVA
        
        
	def estimate(self, ANOVA):
		import scipy.stats as stats
		resANOVA = {}
		ra = ANOVA.ra
		rm = ANOVA.rm
		wwrm = ANOVA.wwrm
		finiterate = ANOVA.finiterate
		resANOVA['ra'] = stats.f_oneway(*ra.values())
		resANOVA['rm'] = stats.f_oneway(*rm.values())
		resANOVA['wwrm'] = stats.f_oneway(*wwrm.values())
		resANOVA['finiterate'] = stats.f_oneway(*finiterate.values())
		return resANOVA
		
	def createTextAnova(self, ANOVA, resANOVA):
		testo = "<b>Anova analysis </b> performed on the datasets:<br>"
		testo += repr(ANOVA.name)
		testo += "<br><br>"
		testo += "ANOVA on Ra index: <br>"
		testo += str(resANOVA['ra'])
		testo += "<br><br>"
		testo += "ANOVA on Rm index: <br>"
		testo += str(resANOVA['rm'])
		testo += "<br><br>"
		testo += "ANOVA on Wyatt and White Rm index: <br>"
		testo += str(resANOVA['wwrm'])
		testo += "<br><br>"
		testo += "ANOVA on Lambda/finite rate index: <br>"
		testo += str(resANOVA['finiterate'])
		testo += "<br><br>"
		return testo
        
	def exportXls(self, resANOVA, ANOVA, fileName):
		from xlwt import Workbook
		book = Workbook()
		sheet1 = book.add_sheet("Anova Analysis")
		r = 0
		sheet1.row(r).write(0, "Anova on Ra indices")
		r += 1
		sheet1.row(r).write(0, "Original data")
		r += 1
		for key in ANOVA.name:
			sheet1.row(r).write(0, key)
			sheet1.row(r).write(1, str(ANOVA.ra[key]))
			r += 1
		r += 1
		sheet1.row(r).write(0, "Result")
		r += 1
		sheet1.row(r).write(0, str(resANOVA['ra']))
		r += 2
		sheet1.row(r).write(0, "Anova on Rm indices")
		r += 1
		sheet1.row(r).write(0, "Original data")
		r += 1
		for key in ANOVA.name:
			sheet1.row(r).write(0, str(key))
			sheet1.row(r).write(1, str(ANOVA.rm[key]))
			r += 1
		r += 1
		sheet1.row(r).write(0, "Result")
		r += 1
		sheet1.row(r).write(0, str(resANOVA['rm']))
		r += 2
		sheet1.row(r).write(0, "Anova on wwRm indices")
		r += 1
		sheet1.row(r).write(0, "Original data")
		r += 1
		for key in ANOVA.name:
			sheet1.row(r).write(0, str(key))
			sheet1.row(r).write(1, str(ANOVA.wwrm[key]))
			r += 1
		r += 1
		sheet1.row(r).write(0, "Result")
		r += 1
		sheet1.row(r).write(0, str(resANOVA['wwrm']))
		r += 2
		sheet1.row(r).write(0, "Anova on Finite rate of increase lambda indices")
		r += 1
		sheet1.row(r).write(0, "Original data")
		r += 1
		for key in ANOVA.name:
			sheet1.row(r).write(0, str(key))
			sheet1.row(r).write(1, str(ANOVA.finiterate[key]))
			r += 1
		r += 1
		sheet1.row(r).write(0, "Result:")
		r += 1
		sheet1.row(r).write(0, str(resANOVA['finiterate']))
		
		ext = fileName.split(".")[-1]
		if ext == "xls":
			book.save(fileName)
		elif ext == "xlsx":
			newName = fileName.split(".")[0] + ".xls"
			book.save(newName)
		else:
			fileName += ".xls"
			book.save(fileName)