# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ProtocolDialog.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ProtocolDialog(object):
    def setupUi(self, ProtocolDialog):
        ProtocolDialog.setObjectName(_fromUtf8("ProtocolDialog"))
        ProtocolDialog.resize(469, 357)
        self.protocolText = QtGui.QPlainTextEdit(ProtocolDialog)
        self.protocolText.setGeometry(QtCore.QRect(10, 40, 451, 271))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Avenir"))
        font.setPointSize(14)
        self.protocolText.setFont(font)
        self.protocolText.setObjectName(_fromUtf8("protocolText"))
        self.label = QtGui.QLabel(ProtocolDialog)
        self.label.setGeometry(QtCore.QRect(10, 10, 451, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Avenir"))
        font.setPointSize(14)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.okButton = QtGui.QPushButton(ProtocolDialog)
        self.okButton.setGeometry(QtCore.QRect(380, 320, 81, 32))
        self.okButton.setObjectName(_fromUtf8("okButton"))
        self.cancelButton = QtGui.QPushButton(ProtocolDialog)
        self.cancelButton.setGeometry(QtCore.QRect(300, 320, 81, 32))
        self.cancelButton.setObjectName(_fromUtf8("cancelButton"))

        self.retranslateUi(ProtocolDialog)
        QtCore.QObject.connect(self.okButton, QtCore.SIGNAL(_fromUtf8("clicked()")), ProtocolDialog.close)
        QtCore.QObject.connect(self.cancelButton, QtCore.SIGNAL(_fromUtf8("clicked()")), ProtocolDialog.close)
        QtCore.QMetaObject.connectSlotsByName(ProtocolDialog)

    def retranslateUi(self, ProtocolDialog):
        ProtocolDialog.setWindowTitle(_translate("ProtocolDialog", "Dialog", None))
        self.protocolText.setPlainText(_translate("ProtocolDialog", "For example following the Pea Protocol by Nardelli et al. 2016:\n"
"\n"
"Species: Myzus persicae\n"
"Rearing temperature: 18°C\n"
"Day and night time: 16h light + 8h dark\n"
"Rearing plant: pea Pisum sativum. Replaced the pea shoots every 12 days\n"
"Counted the newborn everyday for about 20 days till the death of the aphid\n"
"\n"
"... ecc ..", None))
        self.label.setText(_translate("ProtocolDialog", "Here you can write down the protocol you used to collect your data:", None))
        self.okButton.setText(_translate("ProtocolDialog", "OK", None))
        self.cancelButton.setText(_translate("ProtocolDialog", "Cancel", None))

