# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'CiteDialog.ui'
#
# Created by: PyQt4 UI code generator 4.12
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_CiteDialog(object):
    def setupUi(self, CiteDialog):
        CiteDialog.setObjectName(_fromUtf8("CiteDialog"))
        CiteDialog.resize(400, 238)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Avenir Next"))
        CiteDialog.setFont(font)
        self.textEdit = QtGui.QTextEdit(CiteDialog)
        self.textEdit.setGeometry(QtCore.QRect(10, 10, 381, 181))
        self.textEdit.setTextInteractionFlags(QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.textEdit.setObjectName(_fromUtf8("textEdit"))
        self.btnClose = QtGui.QPushButton(CiteDialog)
        self.btnClose.setGeometry(QtCore.QRect(9, 200, 381, 32))
        self.btnClose.setObjectName(_fromUtf8("btnClose"))

        self.retranslateUi(CiteDialog)
        QtCore.QObject.connect(self.btnClose, QtCore.SIGNAL(_fromUtf8("released()")), CiteDialog.close)
        QtCore.QMetaObject.connectSlotsByName(CiteDialog)

    def retranslateUi(self, CiteDialog):
        CiteDialog.setWindowTitle(_translate("CiteDialog", "How to Cite Us", None))
        self.textEdit.setHtml(_translate("CiteDialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Avenir Next\'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'.SF NS Text\'; font-size:12pt;\">How to cite us:</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'.SF NS Text\'; font-size:12pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; color:#222222; background-color:#ffffff;\">Nardelli, A., et al. &quot;Afit: a bioinformatic tool for measuring aphid fitness and invasiveness.&quot; </span><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; font-style:italic; color:#222222;\">Bulletin of Entomological Research</span><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; color:#222222; background-color:#ffffff;\"> (2016): 1-8.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'Arial,sans-serif\'; font-size:12pt; color:#222222;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; color:#222222; background-color:#ffffff;\">Nardelli, A., Peona, V., Toschi, A., Mandrioli, M., &amp; Manicardi, G. C. (2016). Afit: a bioinformatic tool for measuring aphid fitness and invasiveness. </span><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; font-style:italic; color:#222222;\">Bulletin of Entomological Research</span><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; color:#222222; background-color:#ffffff;\">, 1-8.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'Arial,sans-serif\'; font-size:12pt; color:#222222;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; color:#222222; background-color:#ffffff;\">NARDELLI, A., et al. Afit: a bioinformatic tool for measuring aphid fitness and invasiveness. </span><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; font-style:italic; color:#222222;\">Bulletin of Entomological Research</span><span style=\" font-family:\'Arial,sans-serif\'; font-size:12pt; color:#222222; background-color:#ffffff;\">, 2016, 1-8.</span></p></body></html>", None))
        self.btnClose.setText(_translate("CiteDialog", "Close", None))

