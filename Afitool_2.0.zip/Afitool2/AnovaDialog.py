# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'AnovaDialog.ui'
#
# Created by: PyQt4 UI code generator 4.12
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_AnovaDialog(object):
    def setupUi(self, AnovaDialog):
        AnovaDialog.setObjectName(_fromUtf8("AnovaDialog"))
        AnovaDialog.resize(468, 358)
        self.btnClose = QtGui.QPushButton(AnovaDialog)
        self.btnClose.setGeometry(QtCore.QRect(10, 322, 451, 20))
        self.btnClose.setObjectName(_fromUtf8("btnClose"))
        self.textEditAnova = QtGui.QTextEdit(AnovaDialog)
        self.textEditAnova.setGeometry(QtCore.QRect(10, 10, 451, 301))
        self.textEditAnova.setObjectName(_fromUtf8("textEditAnova"))

        self.retranslateUi(AnovaDialog)
        QtCore.QObject.connect(self.btnClose, QtCore.SIGNAL(_fromUtf8("clicked()")), AnovaDialog.close)
        QtCore.QMetaObject.connectSlotsByName(AnovaDialog)

    def retranslateUi(self, AnovaDialog):
        AnovaDialog.setWindowTitle(_translate("AnovaDialog", "Anova Results", None))
        self.btnClose.setText(_translate("AnovaDialog", "Close", None))

