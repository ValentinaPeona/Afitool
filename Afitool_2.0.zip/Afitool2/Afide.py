# Classe base per il calcolo di tutti gli indici e curve

import numpy as np
import re
import math
import Polynomial
from matplotlib.figure import Figure
import matplotlib.patches as mpatches
from matplotlib.backends.backend_qt4agg import (FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar)
import matplotlib.pyplot as plt
plt.style.use('ggplot')

class Afide:
	def __init__(self, nascite, z, xmax, crowding = None):
		self.nascite = nascite
		self.nomiCeppi = []
		for key in nascite:
			self.nomiCeppi.append(key)
		self.xmax = xmax                        # quanti giorni ha vissuto il clone
		self.z = z                              # giorno del primo parto
		self.numCloni = len(self.nomiCeppi)
		self.crescita = {}
		self.ra = {}
		self.rm = {}
		self.wwrm = {}
		self.finiteRate = {}
		self.meanRa = 0
		self.meanWwrm = 0
		self.meanFiniteRate = 0
		self.meanRm = 0
        # il dizionario crowding comprende tre parametri:
        # numero di afidi iniziali = iniPop
        # quanti giorni è durato l'esperimento = days
        # numero di afidi finali = endPop
		self.crowding = crowding
		self.rc = 0
		self.meanRc = 0
		self.rcdev = None
		self.ottenuti = 0
		self.rmdev = None
		self.radev = None
		self.finitedev = None
		self.wwrmdev = None
		self.percentuale = None
		self.longevity = {}
		self.fecundity = {}
		self.xday = {}
		self.yfec = {}
		self.netRate = {}
		self.d = {}
		self.meanD = None
		self.meanLongevity = None
		self.meanFecundity = None
		self.meanXday = None
		self.meanYfec = None
		self.meanNetRate = None
		self.ddev = 0
		self.yfecdev = 0
		self.netratedev = 0
		self.xdaydev = 0
		self.fecunditydev = 0
		self.longevitydev = 0
		self.protocol = None
		self.curvaRc = []

	def setCrowding(self, afidi, crowding):
		afidi.crowding = crowding
        
    
	def growthCurve(self, afidi, nascite, nome):
		import math
		import numpy as np
        
		z = 0
		i = 0
		while nascite[i] == 0 and i < len(nascite):
			z += 1
			i += 1
            
		fecundity = np.array(nascite)
		n = 30
		m = len(nascite)
		Bunnies = np.array([0]*m)
		Rabbits = np.array([1]+[0]*(m-1))
		curva = [0]*n
		Md = 0 # per il calcoloWW-rm

		for giorno in range(0, n):
            # every month I shift the list of 1 since they're getting older
			Rabbits = np.roll(Rabbits, 1)
            # I set the newborns as 0
			Rabbits[0] = 0
            # I calculate the newborns
			Bunnies = Rabbits * fecundity
            # and then I assign them to the rabbits 0 month old
			Rabbits[0] = sum(Bunnies)
            #if giorno <= ((z-1)*2):
            #    Md += sum(Bunnies)
			curva[giorno] = sum(Rabbits)
            
        #Calcolo di Ra
		afidi.crescita[nome] = curva
		x = range(0,10)
        #x = range(1,31)
        #y = curva[:]
		y = curva[20:30]
		for i in range(0, len(y)):
			y[i] = math.log(y[i])
		ra = np.polyfit(x,y,1)[0]
		afidi.ra[nome] = ra
        #vecchio metodo per calcolare il coefficiente angolare
        #afidi.ra[nome] = Afide.pend(curva)

        #Calcolo di rm Birch
        #afidi.rm[nome]
		poly = nascite[::-1] # reverse the list per creare i coefficienti corretti per la risoluzione del polinomio
		L = len(poly) - 1
		poly = poly[0:L]
		poly.append(-1) #aggiungo l'ultimo termine
		for i in range(0, len(poly)):
			if(poly[0] == 0.0):
				del(poly[0])
        
        #risoluzione del polinomio:
		res = Polynomial.FindRoots(poly)
		for i in range(0, len(res)):
			solution = repr(res[i])
			if re.search('0j', solution) and not re.search('-', solution):
				solution = solution.split('+')[0]
				rm = solution
		rm = rm.split('(')[-1]
		rm = float(rm)
		rm = math.log(rm) * (-1)

		afidi.rm[nome] = rm
        
        #Calcolo di WW-rm
		c = (z*2)+1
		if ((c) < len(nascite)):
			Md = sum(nascite[0:(c)])
		else:
			Md = sum(nascite[:])
		afidi.wwrm[nome] = 0.738 * (math.log(Md)) / z

        #Calcolo per d mean generation time
		afidi.d[nome] = z

        #Calcolo di lambda - finite rate of increase lambda = e^rm
        # dato che per adesso non sono riuscita a calcolare rm, uso wwrm come esponente
		afidi.finiteRate[nome] = math.exp(afidi.rm[nome])

        #Calcolo R0 = net rate
		afidi.netRate[nome] = sum(nascite)

        #Calcolo L longevity e poi farne la media
		afidi.longevity[nome] = len(nascite)

        #Calcolo fecondità daily fecundity
        #R0 / L
        #afidi.fecundity[nome] = afidi.netRate[nome] / afidi.longevity[nome]
        # calcolare f come la media dei nati nel periodo fertile
		count = 0
		i = 0
		while nascite[i] == 0:
			count += 1
			i += 1
		afidi.fecundity[nome] = afidi.netRate[nome] / len(nascite[count:])
        
        #Calcolo ymax fecundità giornaliera massima
		afidi.yfec[nome] = max(nascite)

        #Calcolo xday giorno di fecondità massima
		afidi.xday[nome] = nascite.index(max(nascite)) + 1

		return(afidi)

	def pend(f3):

        #CALCOLO DEL ln di f3
		lnf3 = []
		for a in range (0,len(f3)):
			xc = f3[a] 
			lnf3.append(math.log(xc))
    
        #CALCOLO LA PENDENZA DELLA retta
		L = len(lnf3)
        #pendenza da 20 a 30 giorni
		pendenza =  (lnf3[L-1] - lnf3[19])/10
        #pendenza da 0 a 30 giorni
        #pendenza = (lnf3[29] - lnf3[0])/30
		return pendenza

	def crowdingEffect(self, afidi):
        # Calcolo di rc crowding effect
        #attesi = math.exp( float(afidi.crowding['days']) * afidi.meanRa)
        # media della crescita di tutte le repliche al giorno immesso dall'utente
		attesi = 0
		for key in afidi.crescita:
			attesi += afidi.crescita[key][afidi.crowding['days']-1]
		attesi = (attesi / afidi.numCloni) * afidi.crowding['iniPop']
		ottenuti = afidi.crowding['endPop']
		percentuale = 100 - (ottenuti/attesi * 100)
		afidi.percentuale = percentuale
		curvaMedia = np.array([0]*30)
		for key in afidi.crescita:
			curvaMedia += afidi.crescita[key]
		curvaMedia = curvaMedia / afidi.numCloni
		curvaRc = ((curvaMedia / 100) * (100 - percentuale))

		w = str(afidi.nomiCeppi[0])
		s = w.split(" ")[0]
		figRc = Figure()
		ax1 = figRc.add_subplot(111)
		ax1.plot( range(1, 31), curvaMedia, label = "Mean growth curve")
		ax1.plot( range(1, 31), curvaRc, label = "Crowding effect")
		ax1.fill_between( range(1, 31), curvaMedia, curvaRc, color = "k", alpha= 0.2)
		ax1.legend(loc = 2, fancybox = True)
		ax1.set_title('Mean growth curve and crowding effect - ' + s)
		ax1.set_xlabel('Days')
		ax1.set_ylabel('Number of aphids')
		fig_dict = {}
		fig_dict["Crowding effect"] = figRc

		afidi.ottenuti = curvaRc

        #calcolo pendenza e quindi Rc vecchio stile
        #afidi.rc = Afide.pend(curvaRc)
		x = range(0,10)
		L = len(curvaRc) - 10
		y = curvaRc[L:]
		for i in range(0, len(y)):
			y[i] = math.log(y[i])
		rc = np.polyfit(x,y,1)[0]
		afidi.rc = rc

		return(fig_dict)

	def crowdingEffect2(self, afidi):
		c = len(afidi.crowding['days'])
        
		curvaMedia = np.array([0]*30)
		for key in afidi.crescita:
			curvaMedia += afidi.crescita[key]
		curvaMedia = curvaMedia / afidi.numCloni

		curvaRm = np.array([0]*30)
		for i in range(0,30):
			curvaRm[i] = math.exp(afidi.meanRm * i)

		percentuale = []

		for i in range(0,c):
			giorno = afidi.crowding['days'][i]
			attesi = curvaRm[afidi.crowding['days'][i]-1] * afidi.crowding['iniPop'][i]
			ottenuti = afidi.crowding['endPop'][i]
			percentuale.append(100 - (ottenuti/attesi * 100))

		percentuale = []
        
		for i in range(0,c):
			giorno = afidi.crowding['days'][i]
			attesi = curvaMedia[afidi.crowding['days'][i]-1] * afidi.crowding['iniPop'][i]
			ottenuti = afidi.crowding['endPop'][i]
			percentuale.append(100 - (ottenuti/attesi * 100))

		pmedia = np.mean(percentuale)
		afidi.percentuale = pmedia

        # per il plot
		curvaRcMedia = ((curvaMedia / 100) * (100 - pmedia))
		afidi.curvaRc = curvaRcMedia.tolist()

		curvaRc = np.array([0]*30)
		Rc = []
		RcTutto = []
		x = range(1,31)
		y = [0]*30
        
		for i in range(0,c):
			curvaRc = ((curvaMedia / 100) * (100 - percentuale[i]))
			for j in range(0, len(y)):
				if curvaMedia[j] > afidi.crowding['iniPop'][i]:
					y[j] = math.log(curvaRc[j])
				else:
					y[j] = curvaMedia[j]
			RcTutto.append(np.polyfit(x,y,1)[0])

		afidi.rc = np.mean(RcTutto)
		afidi.rcdev = np.std(RcTutto) / math.sqrt( len(RcTutto) )
		curvaRcNuova = np.array([0]*30)
		for i in range(0,30):
			curvaRcNuova[i] = math.exp(afidi.rc * i)
		afidi.curvaRcNuova = curvaRcNuova.tolist()
        
        #plot
		for x in range(0, 30):
			y[x] = math.exp(afidi.meanRa * x)
		w = str(afidi.nomiCeppi[0])
		s = w.split(" ")[0]
		figRc = Figure()
		ax1 = figRc.add_subplot(111)
		ax1.plot( range(1, 31), curvaMedia, label = "Mean growth curve")
		ax1.plot( range(1, 31), curvaRcNuova, label = "Crowding effect")
        #ax1.plot( range(1, 31), y, label = "Advanced intrinsic rate - ra")
		ax1.fill_between( range(1, 31), curvaMedia, curvaRcNuova, color = "k", alpha= 0.2)
		ax1.legend(loc = 2, fancybox = True)
		ax1.set_title('Mean growth curve and crowding effect - ' + s)
		ax1.set_xlabel('Days')
		ax1.set_ylabel('Number of aphids')
		fig_dict = {}
		fig_dict["Crowding effect - Growth Curve"] = figRc

		return(fig_dict)
            
	def meanFitness(self, afidi):
		import numpy as np
        
		index = []
		for key, value in afidi.ra.items():
			index.append(value)
		afidi.meanRa = np.mean(index)
		afidi.radev = np.std(index) / math.sqrt( len(index) )

		index = []
		for key, value in afidi.wwrm.items():
			index.append(value)
		afidi.meanWwrm = np.mean(index)
		afidi.wwrmdev = np.std(index) / math.sqrt( len(index) )

		index = []
		for key, value in afidi.finiteRate.items():
			index.append(value)
		afidi.meanFiniteRate = np.mean(index)
		afidi.finitedev = np.std(index) / math.sqrt( len(index) )
    
		index = []
		for key, value in afidi.rm.items():
			index.append(value)
		afidi.meanRm = np.mean(index)
		afidi.rmdev = np.std(index) / math.sqrt( len(index) )

		index = []
		for key, value in afidi.longevity.items():
			index.append(value)
		afidi.meanLongevity = float(np.mean(index))
		afidi.longevitydev = np.std(index) / math.sqrt( len(index) )

		index = []
		for key, value in afidi.fecundity.items():
			index.append(value)
		afidi.meanFecundity = float(np.mean(index))
		afidi.fecunditydev = np.std(index) / math.sqrt( len(index) )

		index = []
		for key, value in afidi.xday.items():
			index.append(value)
		afidi.meanXday = float(np.mean(index))
		afidi.xdaydev = np.std(index) / math.sqrt( len(index) )

		index = []
		for key, value in afidi.yfec.items():
			index.append(value)
		afidi.meanYfec = float(np.mean(index))
		afidi.yfecdev = np.std(index) / math.sqrt( len(index) )

		index = []
		for key, value in afidi.netRate.items():
			index.append(value)
		afidi.meanNetRate = float(np.mean(index))
		afidi.netratedev = np.std(index) / math.sqrt( len(index) )

		index = []
		for key, value in afidi.d.items():
			index.append(value)
		afidi.meanD = float(np.mean(index))
		afidi.ddev = np.std(index) / math.sqrt( len(index) )

		return(afidi)

	def createGrowthCurve(self, afidi):
		fig1 = Figure()
		media = np.array([0]*30)
		for key, value in afidi.crescita.items():
			ax1x1 = fig1.add_subplot(111)
			ax1x1.plot( range(1,31), value, label = key)
			media += np.array(value)
		media = media / afidi.numCloni
		ax1x1.plot( range(1,31), media, label = "Average growth curve", linewidth = 2)
		ax1x1.set_title('Growth curve predicted from daily fecundity')
		ax1x1.set_xlabel('Days')
		ax1x1.set_ylabel('Number of aphids')
		ax1x1.legend(loc = 2, fancybox = True)
		return(fig1)

	def createIndexCurve(self, afidi, statusRa, statusWhite, statusLambda, statusRm):
		import math
    
		fig_dict = {}
        # y = e^(ra*x)
		y = [0]*30
		if statusRa:
			figRa = Figure()
			for x in range(0, 30):
				y[x] = math.exp(afidi.meanRa * x)
			ax1 = figRa.add_subplot(111)
			ax1.plot( range(1, 31), y, label = "Advanced intrinsic rate - ra")
			ax1.legend(loc = 2, fancybox = True)
			ax1.set_title('Growth curve with ra fitness index')
			ax1.set_xlabel('Days')
			ax1.set_ylabel('Number of aphids')
			fig_dict["Ra"] = figRa
		if statusWhite:
			y = [0]*30
			figWhite = Figure()
			for x in range(0, 30):
				y[x] = math.exp(afidi.meanWwrm * x)
			ax1 = figWhite.add_subplot(111)
			ax1.plot( range(1, 31), y, label = "Intrisic rate of increase - rm by W&W")
			ax1.set_title('Growth curve with WW-rm fitness index')
			ax1.set_xlabel('Days')
			ax1.set_ylabel('Number of aphids')
			ax1.legend(loc = 2, fancybox = True)
			fig_dict["Rm by W&W"] = figWhite
		if statusLambda:
			y = [0]*30
			figLambda = Figure()
			for x in range(0, 30):
				y[x] = math.exp(afidi.meanFiniteRate * x)
			ax1 = figLambda.add_subplot(111)
			ax1.plot( range(1, 31), y, label = "Finite rate of increase - Lambda")
			ax1.set_title('Growth curve with lambda fitness index')
			ax1.set_xlabel('Days')
			ax1.set_ylabel('Number of aphids')
			ax1.legend(loc = 2, fancybox = True)
			fig_dict["λ"] = figLambda
		if statusRm:
			y = [0]*30
			figRm = Figure()
			for x in range(0, 30):
				y[x] = math.exp(afidi.meanRm * x)
			ax1 = figRm.add_subplot(111)
			ax1.plot( range(1, 31), y, label = "Intrisic rate of increase - rm by Birch")
			ax1.set_title('Growth curve with Birch rm fitness index')
			ax1.set_xlabel('Days')
			ax1.set_ylabel('Number of aphids')            
			ax1.legend(loc = 2, fancybox = True)
			fig_dict["Rm by Birch"] = figRm
		return(fig_dict)

	def createIndices(afidi):
		testo = "Intrisic rate of increase by Birch" + "\n"
		testo += "Rm by Birch = " + str(afidi.meanRm) + " ± " + str(afidi.rmdev) + "\n"
		testo += 'z =' + repr(afidi.z) + '\n'
		testo += "Intrisic rate of increase by Wyatt and White" + "\n"
		testo += "WW-rm = " + str(afidi.meanWwrm) + " ± " + str(afidi.wwrmdev) + "\n"
		testo += "Finite rate of increase" + "\n"
		testo += "λ = " + str(afidi.meanFiniteRate) + " ± " + str(afidi.finitedev) + "\n"
		testo += "Intrisic rate of increase of the population" + "\n"
		testo += "Ra = " + str(afidi.meanRa) + " ± " + str(afidi.radev) + "\n"
		testo += "Intrinsic rate of increase of the population in crowding conditions" + "\n"
		testo += "Rc = " + str(afidi.rc) + " ± " + str(afidi.rcdev) + "\n"
		testo += "Crowding effect" + "\n"
		testo += str(afidi.percentuale) + "%" + "\n"
		testo += "Net reproductive rate" + "\n"
		testo += "R0 = " + str(afidi.meanNetRate) + " ± " + str(afidi.netratedev) + "\n"
		testo += "Mean longevity" + "\n"
		testo += "L = " + str(afidi.meanLongevity) + " ± " + str(afidi.longevitydev) + "\n"
		testo += "Daily fecundity" + "\n"
		testo += "f = " + str(afidi.meanFecundity) + " ± " + str(afidi.fecunditydev) + "\n"
		testo += 'Mean generation time' + '\n'
		testo += 'd = ' + str(afidi.meanD) + " ± " + str(afidi.ddev) +'\n'
		testo += "Maximun daily fecundity"  + "\n"
		testo += "Ymax = " + str(afidi.meanYfec) + " ± " + str(afidi.yfecdev) + "\n"
		testo += "Day in which Ymax is reached" + "\n"
		testo += "Xmax = " + str(afidi.meanXday) + " ± " + str(afidi.xdaydev) + "\n"
		return (testo)

	def createIndexNew(afidi):
		testo = "<b>Intrisic rate of increase by Birch </b> <br>"
		testo += "Rm by Birch = " + str(afidi.meanRm) + " ± " + str(afidi.rmdev) + "<br> <br>"
		testo += "<b>Intrisic rate of increase by Wyatt and White </b> " + "<br>"
		testo += "WW-rm = " + str(afidi.meanWwrm) + " ± " + str(afidi.wwrmdev) + "<br> <br>"
		testo += "<b>Finite rate of increase </b>" + "<br>"
		testo += "λ = " + str(afidi.meanFiniteRate) + " ± " + str(afidi.finitedev) + "<br> <br>"
		testo += "<b>Intrisic rate of increase of the population </b>" + "<br>"
		testo += "Ra = " + str(afidi.meanRa) + " ± " + str(afidi.radev) + "<br> <br>"
		testo += "<b>Intrinsic rate of increase of the population in crowding conditions</b>" + "<br>"
		testo += "Rc = " + str(afidi.rc) + " ± " + str(afidi.rcdev) + "<br> <br>"
		testo += "<b>Crowding effect</b>" + "<br>"
		testo += str(afidi.percentuale) + "%" + "<br> <br>"
		testo += "<b>Net reproductive rate </b>" + "<br>"
		testo += "R0 = " + str(afidi.meanNetRate) + " ± " + str(afidi.netratedev) + "<br> <br>"
		testo += "<b>Mean longevity</b>" + "<br>"
		testo += "L = " + str(afidi.meanLongevity) + " ± " + str(afidi.longevitydev) + "<br> <br>"
		testo += "<b>Daily fecundity</b>" + "<br>"
		testo += "f = " + str(afidi.meanFecundity) + " ± " + str(afidi.fecunditydev) + "<br> <br>"
		testo += '<b>Mean generation time</b>' + '<br>'
		testo += 'd = ' + str(afidi.meanD) + " ± " + str(afidi.ddev) + '<br> <br>'
		testo += "<b>Maximun daily fecundity</b>"  + "<br>"
		testo += "Ymax = " + str(afidi.meanYfec) + " ± " + str(afidi.yfecdev) + "<br> <br>"
		testo += "<b>Day in which Ymax is reached</b>" + "<br>"
		testo += "Xmax = " + str(afidi.meanXday) + " ± " + str(afidi.xdaydev) + "<br>"
		return (testo)

	def cloneFecundity(afidi):
		fig2 = Figure()
		ax2 = fig2.add_subplot(111)
		a = np.arange(0, 1, (1 / len(afidi.nomiCeppi)))
		l = len(afidi.nomiCeppi)
		art = [0] * l
		for i in range(0, l):
			x = range(1, len(afidi.nascite[afidi.nomiCeppi[i]])+1)
			y = afidi.nascite[afidi.nomiCeppi[i]]
			ax2.plot(x, y, color = "white")
			ax2.fill_between(x, y, facecolor = "green", alpha = a[i])
			art[i] = mpatches.Patch(color = 'green', alpha = a[i], label = str(afidi.nomiCeppi[i]))
		ax2.set_xlabel('Days')
		ax2.set_ylabel('Number of aphids')
		ax2.legend(handles = art, loc = 0, fancybox = True)
		return(fig2)

	def cloneFecundity2(afidi):
		fig2 = Figure()
		ax2 = fig2.add_subplot(111)
		l = len(afidi.nomiCeppi)
		for i in range(0, l):
			x = range(1, len(afidi.nascite[afidi.nomiCeppi[i]])+1)
			y = afidi.nascite[afidi.nomiCeppi[i]]
			ax2.plot(x, y, label = str(afidi.nomiCeppi[i]))
		ax2.set_title('Compared daily fecundity')
		ax2.set_xlabel('Days')
		ax2.set_ylabel('Number of aphids')
		ax2.legend(fancybox = True, loc = 0)
		return(fig2)

	def saveFile(self):
		name = QtGui.QFileDialog.getSaveFileName(self, 'Save File')
        

	def exportXls(self, afidi, fileName):
		from xlwt import Workbook
		book = Workbook()
		sheet1 = book.add_sheet("Sheet1")
        
		nomi = afidi.nomiCeppi
		r = 0

        # scrivo le daily fecundity
		for i in range(0, len(nomi)):
			r += 1
			sheet1.row(i).write(0, nomi[i])
			for j in range(0, len(afidi.nascite[nomi[i]])):
				sheet1.row(i).write(j+1, afidi.nascite[nomi[i]][j])

		r += 1

        # scrivo la curva di crescita basata su daily fecundity
		sheet1.row(r).write(0, "Growth curve based on daily fecundity")
		for i in range(0, len(nomi)):
			r += 1
			sheet1.row(r).write(0, nomi[i])
			for j in range(0, len(afidi.crescita[nomi[i]])):
				sheet1.row(r).write(j+1, int(afidi.crescita[nomi[i]][j]))
		r += 1

        #scrivo la curva di crescita basata su Rm
		curva = np.array([0]*30)
		for i in range(0,30):
			curva[i] = math.exp(afidi.meanRm * i)
		r += 1
		sheet1.row(r).write(0, "Growth curve based on Rm by Birch")
		for j in range(0, len(curva)):
			sheet1.row(r).write(j+1, int(curva[j]))

		r += 1
		curva = np.array([0]*30)
		for i in range(0,30):
			curva[i] = math.exp(afidi.meanWwrm * i)        
		sheet1.row(r).write(0, "Growth curve based on Rm by W&W")
		for j in range(0, len(curva)):
			sheet1.row(r).write(j+1, int(curva[j]))

		r += 1
		curva = np.array([0]*30)
		for i in range(0,30):
			curva[i] = math.exp(afidi.meanRa * i)
		sheet1.row(r).write(0, "Growth curve based on Ra")
		for j in range(0, len(curva)):
			sheet1.row(r).write(j+1, int(curva[j]))
		r += 1

		sheet1.row(r).write(0, 'Growth curve based on Rc')
		for j in range(0, len(afidi.curvaRcNuova)):
			sheet1.row(r).write(j+1, int(afidi.curvaRcNuova[j]))
		r += 2
        

		r += 1
        # scrivo gli indici con standard error
		sheet1.row(r).write(0, "Fitness Index")
		sheet1.row(r).write(1, "Value")
		sheet1.row(r).write(2, "Standard Error")
		r += 1

        #mean Rm
		sheet1.row(r).write(0, "Mean Rm by Birch")
		sheet1.row(r).write(1, afidi.meanRm)
		sheet1.row(r).write(2, afidi.rmdev)
		r += 1

        #meanWWrm
		sheet1.row(r).write(0, "Mean Rm by W&W")
		sheet1.row(r).write(1, afidi.meanWwrm)
		sheet1.row(r).write(2, afidi.wwrmdev)
		r += 1

        #mean Finite Rate Lambda
		sheet1.row(r).write(0, "Mean Finite Rate Lambda")
		sheet1.row(r).write(1, afidi.meanFiniteRate)
		sheet1.row(r).write(2, afidi.finitedev)
		r += 1

        #meanRa
		sheet1.row(r).write(0, "Mean Ra - Advanced Rate of Increase")
		sheet1.row(r).write(1, afidi.meanRa)
		sheet1.row(r).write(2, afidi.radev)
		r += 1

        #mean Rc
		if afidi.meanRc == 0:
			sheet1.row(r).write(0, "Rc")
			sheet1.row(r).write(1, afidi.rc)
		else:
			sheet1.row(r).write(0, "Mean Rc")
			sheet1.row(r).write(1, afidi.meanRc)
			sheet1.row(r).write(2, afidi.rcdev)

        #Crowding
		r += 1
		if afidi.crowding is None:
			sheet1.row(r).write(0, "Crowding data not available")
		else:
			sheet1.row(r).write(0, "Crowding effect %")
			sheet1.row(r).write(1, afidi.percentuale)

		r += 1
		sheet1.row(r).write(0, 'Net rate R0')
		sheet1.row(r).write(1, afidi.meanNetRate)
		sheet1.row(r).write(2, afidi.netratedev)

		r += 1
		sheet1.row(r).write(0, 'Mean generation time D')
		sheet1.row(r).write(1, afidi.meanD)
		sheet1.row(r).write(2, afidi.ddev)

        #Longevity
		r += 1
		sheet1.row(r).write(0, 'Total longevity L')
		sheet1.row(r).write(1, afidi.meanLongevity)
		sheet1.row(r).write(2, afidi.longevitydev)
        
        #Daily fecundity f
		r += 1
		sheet1.row(r).write(0, 'Daily fecundity f')
		sheet1.row(r).write(1, afidi.meanFecundity)
		sheet1.row(r).write(2, afidi.fecunditydev)
        
        #Maximum fecundity (offspring) Ymax
		r += 1
		sheet1.row(r).write(0, 'Maximum fecundity (offspring) Ymax')
		sheet1.row(r).write(1, afidi.meanYfec)
		sheet1.row(r).write(2, afidi.yfecdev)
        
        #Day of maximum fecundity (offspring) Xmax
		r += 1
		sheet1.row(r).write(0, 'Day of maximum fecundity (offspring) Xmax')
		sheet1.row(r).write(1, afidi.meanXday)
		sheet1.row(r).write(2, afidi.xdaydev)
        
		ext = fileName.split(".")[-1]
		if ext == "xls":
			book.save(fileName)
		elif ext == "xlsx":
			newName = fileName.split(".")[0] + ".xls"
			book.save(newName)
		else:
			fileName += ".xls"
			book.save(fileName)