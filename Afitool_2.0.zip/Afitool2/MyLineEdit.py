# classi pyqt reimplementate

from PyQt4 import QtCore, QtGui

class MyLineEdit(QtGui.QLineEdit):
    textModified = QtCore.pyqtSignal(str, str) # (before, after)
    
    #def __init__(self, contents= '', parent=None):
    def __init__(self, parent = None):
        #super(MyLineEdit, self).__init__(contents, parent)
        super(MyLineEdit, self).__init__(parent)
        #self.returnPressed.connect(self.checkText)
        #self.before = contents

        
    def mousePressEvent(self, event):
        #print('Mouse pressed on widget')
        self.selectAll()

    #def focusInEvent(self, event):
    #    if event.reason() != QtCore.Qt.PopupFocusReason:
    #        self.before = self.text()
    #    super(MyLineEdit, self).focusInEvent(event)

    #def focusOutEvent(self, event):
    #    if event.reason() != QtCore.Qt.PopupFocusReason:
    #        self.checkText()
    #    super(MyLineEdit, self).focusOutEvent(event)

    #def checkText(self):
    #    if self.before != self.text():
    #        self.before = self.text()
    #        self.textModified.emit(self.before, self.text())
